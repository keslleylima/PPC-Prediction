---
name: Question
about: Have a question wanted to be help
title: "[Question] Question title"
assignees: ''

---

**For better global communication, Please describe it in English. If you feel the description in English is not clear, then you can append description in Chinese(just for Mandarin(CN)), thx! **
**Describe the question**
A clear and concise description of what the question is.


**Which version of DolphinScheduler:**
 -[1.1.0-preview]

**Additional context**
Add any other context about the problem here.

**Requirement or improvement**
- Please describe about your requirements or improvement suggestions.
