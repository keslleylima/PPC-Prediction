package com.urbanairship.api.push.model.audience.createandsend;

public class OpenChannel {

}
