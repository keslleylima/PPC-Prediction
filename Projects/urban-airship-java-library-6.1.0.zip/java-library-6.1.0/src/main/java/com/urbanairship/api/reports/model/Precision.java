package com.urbanairship.api.reports.model;

/**
 * Enum of precisions.
 */
public enum Precision {
    HOURLY,
    DAILY,
    MONTHLY;
}