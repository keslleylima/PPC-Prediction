# Contribution Agreement

## What is the Contributor License Agreement, and what does it mean?

The Contributor License Agreement (CLA) below is to ensure that when someone contributes code to one of our open source libraries that we have a clear record of the license to use it. This is necessary so that we can ensure to all of our customers that they can make use of our libraries and tools without worry. You retain copyright of all of your code.

Please read through the agreement at the URL below. 

If you have questions about this agreement or why we need it please contact us at https://support.airship.com/.

[Contribution Agreement](https://docs.google.com/forms/d/e/1FAIpQLScErfiz-fXSPpVZ9r8Di2Tr2xDFxt5MgzUel0__9vqUgvko7Q/viewform)